# Camera Interface Guide for Hello FPGA Kit (M2S010-IVF256)

This document provides a comprehensive walkthrough for building an image capture pipeline using the **Hello FPGA Kit** featuring the Microsemi SmartFusion2 (M2S010-IVF256) SoC FPGA and the OmniVision **OV7725** camera daughterboard under the **Libero SoC** design suite.

---

## 1. Architectural Architecture & Dataflow

The system utilizes a split-architecture approach leveraging both the FPGA fabric and the ARM Cortex-M3 Hard Microcontroller Subsystem (MSS):

1. **Control Path (I2C/SCCB):** The ARM Cortex-M3 processor uses its hard I2C peripheral to configure the camera's internal registers on startup (setting resolution to QVGA/VGA, enabling RGB565 color format, adjusting gain/exposure).
2. **Data Path (Parallel Video Interface):** The raw high-speed pixel stream bypasses the processor and flows directly into the custom Verilog logic in the FPGA fabric. It synchronizes with the camera's pixel clock (`PCLK`), formats the bytes, and temporarily buffers them in Dual-Port block RAM (LSRAM).

---

## 2. Firmware Implementation (ARM Cortex-M3 Configuration)

The OV7725 sensor acts as an I2C slave (7-bit address typically `0x21`). The firmware runs inside Microchip's SoftConsole IDE. It sets up the MSS I2C driver and sends a sequence of register-value pairs to set up the camera.

### Crucial Register Profiles (RGB565 Layout):
* **COM7 (0x12):** Reset the chip, then set value `0x06` to enable RGB output mode.
* **COM3 (0x0C):** Set value `0x00` to ensure no orientation flip unless desired.
* **CLKRC (0x11):** Sets internal clock prescaler.
* **COM15 (0x40):** Select output range and explicitly enable RGB565 format configurations (`0xD0` or `0x10` depending on your MSB/LSB swap preferences).

---

## 3. Hardware Implementation (Verilog Capture Logic)

The camera streams data via a 8-bit bus `D[7:0]`, alongside `PCLK` (Pixel Clock), `HREF` (Horizontal Reference), and `VSYNC` (Vertical Sync).

### Timing and Protocol Logic:
* **VSYNC Pulse:** A rising/falling edge indicates the start of a brand new frame. This resets our write addresses and state machines back to the top-left pixel `(0,0)`.
* **HREF Gating:** When `HREF` is high, valid pixel bytes are actively arriving on `D[7:0]`.
* **Pixel Reassembly:** Because the bus is 8 bits wide and RGB565 is a 16-bit color format (5 bits Red, 6 bits Green, 5 bits Blue), each complete pixel takes **two consecutive PCLK cycles** to transmit. The fabric logic must latch Byte 1 on the first cycle, wait for Byte 2 on the second cycle, combine them into `[15:0] pixel_data`, and then assert a `write_enable` pulse to save it into a FIFO or Block RAM.

---

## 4. Libero SoC Implementation Workflow

### Step 1: Instantiate the Components
Within your Top-Level **SmartDesign** canvas:
1. Drag the **SmartFusion2 MSS** block into the canvas. Configure the MSS Clocks and enable the `I2C_0` controller, routing its signals to the FPGA fabric or package pins.
2. Instantiate the **CoreI2C** IP block if preferred over the MSS Hard I2C.
3. Right-click the workspace, create a new HDL component, paste the `ov7725_capture.v` source code, and generate the block wrapper to link it into the SmartDesign.
4. From the IP Catalog, drop a **Dual-Port Large SRAM (LSRAM)** block or a **FIFO** block to decouple your camera clock domain (`PCLK`) from your system processing clock domain.

### Step 2: Set Physical I/O Constraints
Open the **Constraints Editor** -> **I/O Editor** to map your structural ports to the actual hardware pins of the expansion header on the M2S010-IVF256 package.

Ensure all video pins (`PCLK`, `VSYNC`, `HREF`, `D[7:0]`) are configured as **Inputs** using the **LVCMOS33** or **LVCMOS25** standard depending on your daughterboard rail configuration. Turn on internal pull-ups for the I2C lines (`SIOC` and `SIOD`) if the daughterboard lacks physical resistor pull-ups.

### Step 3: Synthesis & Tool Chain Generation
1. Run **Synthesize** to translate your structural Verilog blocks.
2. Run **Place and Route** to map resources inside the SmartFusion2 fabric matrix.
3. Verify timing constraints—specifically checking that your setup and hold times for `D[7:0]` are compliant with the incoming `PCLK` transitions.
4. Run **Generate Bitstream** and flash the hardware using **FlashPro**.
