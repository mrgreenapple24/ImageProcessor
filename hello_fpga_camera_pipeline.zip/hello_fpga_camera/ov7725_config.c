/***************************************************************************
 * File Name:    ov7725_config.c
 * Target:       SmartFusion2 M2S010 Cortex-M3 (SoftConsole IDE)
 * Description:  Basic runtime initialization configuration arrays and I2C 
 * write sequence handlers for the OV7725 sensor registers.
 ***************************************************************************/

#include "drivers/mss_i2c/mss_i2c.h"

#define OV7725_I2C_ADDR    0x21  // Standard 7-bit I2C Slave Address

typedef struct {
    uint8_t reg_num;
    uint8_t value;
} reg_cfg_t;

// Example Configuration Registry Sequence for RGB565 Configuration
const reg_cfg_t ov7725_init_reg_map[] = {
    {0x12, 0x80}, // COM7:  Execute complete internal chip reset
    {0x3D, 0x03}, // COM12: Fixed analog processing parameters
    {0x12, 0x06}, // COM7:  Configure output format to standard RGB
    {0x11, 0x01}, // CLKRC: Internal clock prescaler configuration 
    {0x15, 0x00}, // COM10: Output Control (VSYNC, HREF configuration)
    {0x40, 0xD0}, // COM15: Select RGB565 range configuration
    {0x17, 0x22}, // HSTART: Horizontal frame origin alignment parameter
    {0x18, 0xA4}, // HSIZE: Horizontal width limit parameters
    {0x19, 0x07}, // VSTRT: Vertical frame origin parameters
    {0x1A, 0xF0}  // VSIZE: Vertical layout definitions
};

#define REG_MAP_SIZE (sizeof(ov7725_init_reg_map)/sizeof(reg_cfg_t))

/* Write configuration map safely over the established MSS I2C master channel */
void init_ov7725_sensor(void) {
    uint8_t tx_buffer[2];
    
    // Explicit initialization of the hard MSS I2C Peripheral
    MSS_I2C_init(&g_mss_i2c0, OV7725_I2C_ADDR, MSS_I2C_PCLK_DIV_256);

    for(int i = 0; i < REG_MAP_SIZE; i++) {
        tx_buffer[0] = ov7725_init_reg_map[i].reg_num;
        tx_buffer[1] = ov7725_init_reg_map[i].value;
        
        MSS_I2C_write(
            &g_mss_i2c0,
            OV7725_I2C_ADDR,
            tx_buffer,
            2,
            MSS_I2C_RELEASE_BUS
        );
        
        // Add a micro-delay structure here to give the camera time to settle registers
        for(volatile int delay = 0; delay < 10000; delay++);
    }
}
