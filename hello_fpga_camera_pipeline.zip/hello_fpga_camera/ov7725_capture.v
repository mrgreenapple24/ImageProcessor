// =========================================================================
// Module Name:    ov7725_capture
// Target Device:  Microsemi SmartFusion2 M2S010-IVF256
// Description:    Captures 8-bit parallel video stream from OV7725 sensor, 
//                 reassembles two 8-bit transfers into single 16-bit RGB565 
//                 pixels, and generates write control flags for memory buffers.
// =========================================================================

module ov7725_capture (
    // Camera Hardware Interface Inputs
    input  wire        pclk,         // Pixel Clock input from camera
    input  wire        vsync,        // Vertical Sync pulse 
    input  wire        href,         // Horizontal Reference pulse (high during valid row data)
    input  wire [7:0]  d,            // 8-bit parallel pixel data bus

    // Fabric Core Output Controls
    output reg  [15:0] pixel_data,   // Reassembled 16-bit RGB565 pixel 
    output reg         pixel_valid,  // Asserted high for 1 cycle when pixel data is ready
    output reg  [18:0] mem_addr      // Memory write address pointer (for QVGA/VGA buffers)
);

    // Track byte sequence parity (0 = High Byte [R/G], 1 = Low Byte [G/B])
    reg        byte_phase;
    reg [7:0]  latched_byte;
    reg        vsync_d;

    // Detect edges on VSYNC to trigger frame-start resets cleanly
    always @(posedge pclk) begin
        vsync_d <= vsync;
    end

    always @(posedge pclk) begin
        // If VSYNC goes high, clear address counter and reset data phase tracking
        if (vsync) begin
            mem_addr     <= 19'b0;
            byte_phase   <= 1'b0;
            pixel_valid  <= 1'b0;
            pixel_data   <= 16'b0;
        end else begin
            if (href) begin
                if (byte_phase == 1'b0) begin
                    // Phase 0: Capture the first byte (Upper 8 bits of RGB565)
                    latched_byte <= d;
                    byte_phase   <= 1'b1;
                    pixel_valid  <= 1'b0;
                end else begin
                    // Phase 1: Capture second byte, concatenate, and output
                    pixel_data   <= {latched_byte, d};
                    pixel_valid  <= 1'b1;
                    byte_phase   <= 1'b0;
                    
                    // Advance internal memory write location pointer
                    mem_addr     <= mem_addr + 1'b1;
                end
            end else begin
                // Reset phase sequence tracker outside of active horizontal line windows
                byte_phase   <= 1'b0;
                pixel_valid  <= 1'b0;
            end
        end
    end

endmodule
